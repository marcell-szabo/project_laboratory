import boto3
import json
import ebooklib
from ebooklib import epub
import time
import re
import io


def lambda_handler(event, context):
    # gets epub from S3 into bytesIO
    s3 = boto3.client('s3')
    s3_info = event['Records'][0]['s3']
    bucketname = s3_info['bucket']['name']
    objectkey = s3_info['object']['key']
    data_stream = io.BytesIO()
    s3.download_fileobj(bucketname, objectkey, data_stream)

    book = epub.read_epub(data_stream)
    html_list = []
    for doc in book.get_items_of_type(ebooklib.ITEM_DOCUMENT):
        html_list.append(doc.get_body_content().decode("utf-8"))
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', html_list[2])
    return {
        'statuscode': 200,
        'body': json.dumps(cleantext)
    }